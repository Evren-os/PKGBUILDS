// Re-export from consolidated editor-state-store for backward compatibility
export { useEditorStateStore } from "@/features/editor/stores/state-store";
