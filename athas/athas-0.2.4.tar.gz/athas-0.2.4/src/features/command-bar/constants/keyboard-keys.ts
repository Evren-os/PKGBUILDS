// Keyboard key constants
export const KEY_ESCAPE = "Escape";
export const KEY_ARROW_DOWN = "ArrowDown";
export const KEY_ARROW_UP = "ArrowUp";
export const KEY_ENTER = "Enter";
export const KEY_K = "k";
