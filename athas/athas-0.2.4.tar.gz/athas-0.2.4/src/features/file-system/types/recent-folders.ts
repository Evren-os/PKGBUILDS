export interface RecentFolder {
  name: string;
  path: string;
  lastOpened: string;
}
